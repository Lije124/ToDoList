function todoItem(text, priority) {
    this.text = text;
    this.priority = priority;
}

var list = [];
var listItem;
var buttonID;

var addItem = document.getElementById("add");
var addButton = addItem.addEventListener("click", addTodoItem);



    
function addTodoItem() {
    
    let textValue = document.getElementById("setItem").value;
    let priValue = document.getElementById("setPri").value;
    listItem = new todoItem(textValue, priValue);
    list.push(listItem);
    let i = list.indexOf(listItem);
    
    var itemDiv = document.createElement("div"); 
    itemDiv.id = "td" + i;
    itemDiv.className = "itembox";
    var boxAdd = document.getElementById("toDoList").appendChild(itemDiv);
        
    var textHeading = document.createElement("h2"); 
    textHeading.innerHTML = textValue;
    var textAdd = document.getElementById(itemDiv.id).appendChild(textHeading);
        
    var priHeading = document.createElement("h3"); 
    priHeading.innerHTML = "Priority: " + priValue;
    var priAdd = document.getElementById(itemDiv.id).appendChild(priHeading);
    
    var doneBox = document.createElement("div"); 
    doneBox.className = "doneBox";
    doneBox.id = "db" + i;
    var doneAdd = document.getElementById(itemDiv.id).appendChild(doneBox);
        
    var doneButton = document.createElement("button"); 
    doneButton.id = "done" + i;
    doneButton.className = "done";
    doneButton.innerHTML = "Done";
    doneButton.onclick = "reply_click(this.id)";
    var doneAdd = document.getElementById(itemDiv.id).appendChild(doneButton);
    
    }


function reply_click(clicked_id)
{
    buttonID = clicked_id;
    let buttonIndex = buttonID.slice(-1);
    var boxID = "db" + buttonIndex;
    markTodoItemAsDone(boxID);
}

function markTodoItemAsDone(boxID) {
     thisBox = document.getElementById(boxID);
     thisBox.innerHTML = "<img src='images/check.gif' />";   
} 
    
 /*   return {
        addTodoItem: addTodoItem,
        markTodoItemAsDone: markTodoItemAsDone
    }
    
    
} */
